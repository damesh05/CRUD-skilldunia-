const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());

// Sample student data (to simulate a database)
let students = [
    { id: 1, firstName: 'John', lastName: 'Doe', rollNo: '123' },
    { id: 2, firstName: 'Jane', lastName: 'Smith', rollNo: '456' }
];

// Routes

// Get all students
app.get('/api/students', (req, res) => {
    res.json(students);
});

// Get a single student by ID
app.get('/api/students/:id', (req, res) => {
    const student = students.find(s => s.id === parseInt(req.params.id));
    if (!student) return res.status(404).json({ message: 'Student not found' });
    res.json(student);
});

// Create a new student
app.post('/api/students', (req, res) => {
    const { firstName, lastName, rollNo } = req.body;
    const id = students.length + 1;
    const newStudent = { id, firstName, lastName, rollNo };
    students.push(newStudent);
    res.status(201).json(newStudent);
});

// Update an existing student
app.put('/api/students/:id', (req, res) => {
    const student = students.find(s => s.id === parseInt(req.params.id));
    if (!student) return res.status(404).json({ message: 'Student not found' });
    const { firstName, lastName, rollNo } = req.body;
    student.firstName = firstName;
    student.lastName = lastName;
    student.rollNo = rollNo;
    res.json(student);
});

// Delete a student
app.delete('/api/students/:id', (req, res) => {
    const index = students.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) return res.status(404).json({ message: 'Student not found' });
    const deletedStudent = students.splice(index, 1)[0];
    res.json({ message: 'Student deleted successfully', student: deletedStudent });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
